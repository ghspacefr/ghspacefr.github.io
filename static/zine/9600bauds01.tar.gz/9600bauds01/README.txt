
                      _______ _______ _______ _______ 
                     |   _   |   _   |   _   |   _   |                    
                     |   |   |   1___|.  |   |.  |   |
                      \___   |.     \|.  |   |.  |   |
                     |:  1   |:  1   |:  1   |:  1   |
                     |::.. . |::.. . |::.. . |::.. . |
                     `-------`-------`-------`-------' bauds

                            ISSUE No 1 - Oct 2025

                                9600@ghspace.fr
                           #9600 sur irc.libera.chat


┌────────────┐
│ DISCLAIMER └─────────────────────────────────────────────────────────────────┐
│ Ce zine est une oeuvre collective, à but informatif, écrite par des gens qui |
| savent (parfois) ce qu'ils font. En aucun cas ils ne peuvent être tenus      |
| responsables de vos bêtises.                                                 │
└──────────────────────────────────────────────────────────────────────────────┘

-- INFO --

9600 bauds est un ezine inter-hackerspaces francophones à l'initiative de
GRENOBLE HACKERSPACE. Vous pouvez partager vos projets, vos actualités, vos
réflexions, vos tutoriels, vos retours d’expérience, ou tout autre contenu de
votre communauté dans un format volontairement minimaliste et nostalgique

-- TREE --

.
├── 00.txt
├── 01.txt
├── 02.txt
├── 03.txt
├── 04.txt
├── 05.txt
├── 06.txt
├── cfp
│   ├── cfp.sig
│   └── cfp.txt
└── README.txt

-- RTFM --

le zine est divisé en plusieurs articles, chacun représenté par un fichier texte
(.txt). Vous pouvez les lire dans n'importe quel ordre avec l'éditeur ou 
visualiseur de votre choix (cat, vim, nano etc...)

Le répertoire `cfp` contient l'appel à contribution.

-- CONTACT --

Tu peux nous contacter via :

- IRC:    #9600 sur irc.libera.chat 6667
- EMAIL:  Staff 9600 <9600@ghspace.fr>

Besoin de confidentialité ?

-----BEGIN PGP PUBLIC KEY BLOCK-----

mDMEaMau5BYJKwYBBAHaRw8BAQdAIriSQTvU+voZh3ol3A5lZpOzO0Hf4a3ie5dc
0TAcQTy0HFN0YWZmIDk2MDAgPDk2MDBAZ2hzcGFjZS5mcj6IkwQTFgoAOxYhBDxY
ZnlHx05Ta/BFq3t6TmyI4pAlBQJoxq7kAhsDBQsJCAcCAiICBhUKCQgLAgQWAgMB
Ah4HAheAAAoJEHt6TmyI4pAl4rUA/2RhQ1zFNjG1sbpYn2yhd4vW6ELWv3jbHSbv
k9hxhFAYAP436htohxy36vUY/lZAaShInBXd3ThVcfgbGZ04rfy7BLg4BGjGruQS
CisGAQQBl1UBBQEBB0BXqqHHKxM0ZPHJty2Hzn8MGL5Mn1R6BiaGbCDqW122UgMB
CAeIeAQYFgoAIBYhBDxYZnlHx05Ta/BFq3t6TmyI4pAlBQJoxq7kAhsMAAoJEHt6
TmyI4pAlog4A/2/eb+Y/CwJhIJ8WUS3ftNw6Yi929SBizt9JAu5eVpACAQCyu6ku
/U2Zk/Ia96Lc3J0CoresASYjVc2vjt+7V9uVAQ==
=Rvqt
-----END PGP PUBLIC KEY BLOCK-----
                  ________            _______
         /\ \ \ \/_______/     ______/\      \  /\ \/ /\ \/ /\  \_____________
        /\ \ \ \/______ /     /\    /:\\      \ ::\  /::\  /::\ /____  ____ __
       /\ \ \ \/_______/     /:\\  /:\:\\______\::/  \::/  \::///   / /   //
      /\ \ \ \/_______/    _/____\/:\:\:/_____ / / /\ \/ /\ \///___/ /___//___
_____/___ \ \/_______/    /\::::::\\:\:/_____ / \ /::\  /::\ /____  ____  ____
         \ \/_______/    /:\\::::::\\:/_____ /   \\::/  \::///   / /   / /   /
          \/_______/    /:\:\\______\/______/_____\\/ /\ \///___/ /___/ /_____
\          \______/    /:\:\:/_____:/\      \ ___ /  /::\ /____  ____  _/\::::
\\__________\____/    /:\:\:/_____:/:\\      \__ /_______/____/_/___/_ /  \:::
//__________/___/   _/____:/_____:/:\:\\______\ /                     /\  /\::
///\          \/   /\ .----.\___:/:\:\:/_____ // \                   /  \/  \:

-- EOF --
